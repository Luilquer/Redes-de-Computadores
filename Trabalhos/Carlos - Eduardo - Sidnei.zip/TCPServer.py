# Carlos Luilquer A. Santos
# Eduardo Zago
# Sidnei de Souza Junior
    
import socket

checkPar = 0

frase = []
server = socket.socket()                                        # VARIAVEL PARA SOCKET
ip = '0.0.0.0'                                                  # ACEITANDO QUALQUER IP REQUEST
port = 12345                                                    # PORTA DO SERVICO TCP
address = (ip, port)                                            # SALVANDO NA VARIAVEL
server.bind(address)                                            # LIGAR O ENDERECO
server.listen(1)                                                # ESCUTANDO APENAS UMA UNICA VEZ
print("* Iniciando a escuta pelo ",ip, ":", port)               # MOSTRANDO A CONECAO DO SERVIDOR PELO IP E PORTA
client, addr = server.accept()                                  # ACEITANDO A CONEXAO COM O CLIENT
print("** Comecao uma conexao de ",addr[0], ":", addr[1])       # MOSTRANDO AONDE ESTA SENDO FEITO A CONEXAO
while True:                                                     # LOOP INFINITO
    data = client.recv(1)                                       # RECEBENDO APENAS UM BYTE DE DADO
    print("\nDado recebido: ", data)                                   # MOSTRANDO O DADO RECEBIDO PELO CLIENT
    if(data == b'\xff'):                                        # SE CASO FOR 255(DECIMAL) É FINALIZADO O PROGRAMA
        print("Acabou \n 255")                                  # APENAS MOSTRANDO QUAL O VALOR EM DECIMAL
        s = ''.join(frase)
        client.send(bytes(s, encoding="CP850"))
        print(s)
        server.close()                                          # FINALIZANDO A CONEXAO DO SERVIDOR
        exit()                                                  # FINALIZANDO O PROGRAMA
    elif(data == b'\x00'):                                            # SE CASO FOR O INICIO DA MENSAGEM
        print("Comecou \n 0")                                   # APENAS PRINTANDO
        checkPar = 1      
    else:                                                       # CASO NADA FOR VERDADEIRO
        #print(data,"\n")                                        # VAI PRINTAR O DADO 
        valor = int.from_bytes(data, "little")                  # AQUI ESTOU CONVERTENDO DE BYTE PARA INT
        print("valor em decimal: ", valor)
        print("check Par: ", checkPar)
        if((valor % 2) == 0):
            
            print("Resultado se é par: ", ((valor % 2) == 0))
            if(checkPar == 0):                                  # siginifica que o numero anterior era impar
                checkPar = 1                                    # siginifica inverter o bit menos significativo do proximo valor
                if(valor > 127):                                # bit de maior significativo com 1
                    print("Char descriptofragado valor em Decimal: ",(int(valor) - int(128)))
                    print("Char descriptofragado: ",chr(int(valor) - int(128)))                    
                    frase.append(chr(int(valor) - int(128)))
                else:                                           #bit de maior significativo com 0
                    print("Char descriptofragado valor em Decimal: ",(int(valor) + int(1)))
                    print("Char descriptofragado: ",chr(int(valor) + int(1)))                       
                    frase.append(chr(int(valor) + int(1)))
                    
            else:                                               # signifiva que o numero anterior era par
                checkPar = 1                                    # siginifica inverter o bit menos significativo do proximo valor
                if(valor > 127):                                # bit de maior significativo com 1
                    print("Char descriptofragado valor em Decimal: ",(int(valor) - int(128)))
                    print("Char descriptofragado: ",chr(int(valor) - int(128)))                    
                    frase.append(chr(int(valor) - int(128)))
                else:                                           #bit de maior significativo com 0
                    print("Char descriptofragado valor em Decimal: ",(int(valor) + int(1)))
                    print("Char descriptofragado: ",chr(int(valor) + int(1)))                                                       
                    frase.append(chr(int(valor) + int(1)))

                
        else:                                                   # significa que o numero é impar
            
            print("Resultado se é par: ", ((valor % 2) == 0))
            if(checkPar == 1):                                  # signifiva que o numero anterior era par
                checkPar = 0    
                if(valor > 127):                                # bit de maior significativo com 1
                    print("Char descriptofragado valor em Decimal: ",(int(valor) - int(128)))
                    print("Char descriptofragado: ",chr(int(valor) - int(128)))                    
                    frase.append(chr(int(valor) - int(128)))
                else:                                           #bit de menor significativo com 0
                    print("Char descriptofragado valor em Decimal: ",(int(valor) - int(1)))
                    print("Char descriptofragado: ",chr(int(valor) - int(1)))                                                                       
                    frase.append(chr(int(valor) - int(1)))

                
            else:                                               # signifiva que o numero anterior era impar
                checkPar = 0
                if(valor > 127):                                # bit de maior significativo com 1                    
                    print("Char descriptofragado valor em Decimal: ",(int(valor) - int(128)))
                    print("Char descriptofragado: ",chr(int(valor) - int(128)))
                    frase.append(chr(int(valor) - int(128)))
                else:                                           #bit de menor significativo com 0
                    print("Char descriptofragado valor em Decimal: ",(int(valor) - int(1)))
                    print("Char descriptofragado: ",chr(int(valor) - int(1)))
                    frase.append(chr(int(valor) - int(1)))                        
        