# Carlos Luilquer A. Santos
# Eduardo Zago
# Sidnei de Souza Junior

from socket import * # importandoo sockets para o programa
import time          # importando o time para fazee o STOP-AND-WAIT


def colocandoParaDormir(tempo):                     # FUNCAO DE STOP-AND-WAIT
    time.sleep(tempo)                               # FUNCAO SLEEP

serverName = '54.94.253.140'                            # DEFININDO QUAL O IP HOST QUE IRÁ SERÁ ENVIADO OS PACOTES
serverPort = 54321                                  # DEFININDO A PORTA DE ENTRADA NO HOST UDP
qtdsDeLetrasOriginal = 0
qtdsDeLetrasRecebido = 0
clientSocket = socket(AF_INET, SOCK_DGRAM)          # DEFININDO COMO PROTOCOLO DE TCP
file = open("GRUPO3.txt", "r", encoding="UTF-8")    # ABERTURA DO ARQUIVO E FAZENDO A LEITURA PELO UTF-8
encode = file.read()                                # SALVANDO NA VARIAVEL O TEXTO
for line in encode:                                 # LENDO O CONTEUDO DA PRIMEIRA LINHA DO TEXTO TODO
    for i in line:                                  # PEGANDO CARACTER POR CARACTER EM CADA LINHA
        qtdsDeLetrasOriginal += 1 
        colocandoParaDormir(0.01)                   # FAZENDO UM STOP-AND-WAIT ANTES DE ENVIAR O PACOTE (PARAR NAQUELE TEMPO)
        byte = bytes(i, encoding="CP850")           # SALVANDO E FAZENDO O ENCONDING DO CARACTER ANTES DE ENVIAR
        clientSocket.sendto(byte, (serverName,serverPort))                   # ENVIANDO O BYTE
            

modifiedMessage, serverAddress = clientSocket.recvfrom(4096) # RECEBENDO O CONTEUDO DO SERVIDOR mas nao esta funci
print (modifiedMessage.decode("UTF-8"))
fileRecv = modifiedMessage.decode("UTF-8")
for line in fileRecv:                                 # LENDO O CONTEUDO DA PRIMEIRA LINHA DO TEXTO TODO
    for i in line:  
        qtdsDeLetrasRecebido += 1
clientSocket.close()                                # FECHANDO A CONEXAO

print("Tamanho do texto original: ", qtdsDeLetrasOriginal)
print("Tamanho do texto recebido: ", qtdsDeLetrasRecebido)
print("Porcentagem dos dados recebidos: ", round(qtdsDeLetrasRecebido/qtdsDeLetrasOriginal*100, 2), "%")